from U_stats import ustat
import numpy as np
import torch
import time
from U_stats._utils._backend import set_backend

set_backend("torch", "cpu")

def test_tensor_performance():
    """Test tensor contraction performance across different methods and sizes"""
    
    # Define the motif expression
    mode = [["1", "2"], ["2", "3"], ["3", "4"], ["4", "5"], ["5", "6"], ["6", "7"]]
    
    # Test different tensor sizes
    sizes = [100, 200, 300, 500, 700, 1000]
    
    print("=" * 80)
    print("Tensor Contraction Performance Test")
    print("=" * 80)
    print(f"{'Size':<8} {'Method':<25} {'Time(s)':<12} {'Result':<15} {'Match':<8}")
    print("-" * 80)
    
    for size in sizes:
        print(f"\nTesting tensor size: {size}x{size}")
        
        # Generate random tensor
        np.random.seed(42)  # For reproducible results
        tensor = np.random.rand(size, size)
        tensors = [tensor for _ in range(6)]
        
        results = {}
        times = {}
        
        # Test Method 1: _einsum=False, _dediag=False (baseline)
        start_time = time.time()
        result_1 = ustat(
            tensors=tensors, 
            expression=mode, 
            average=True, 
            path_method="double-greedy-degree-then-fill", 
            _einsum=False, 
            _dediag=False
        )
        times['baseline'] = time.time() - start_time
        results['baseline'] = result_1
        
        # Test Method 2: _einsum=False, _dediag=True
        start_time = time.time()
        result_2 = ustat(
            tensors=tensors, 
            expression=mode, 
            average=True, 
            path_method="double-greedy-degree-then-fill", 
            _einsum=False, 
            _dediag=True
        )
        times['path_dediag'] = time.time() - start_time
        results['path_dediag'] = result_2
        
        # Test Method 3: _einsum=True, _dediag=True
        start_time = time.time()
        result_3 = ustat(
            tensors=tensors, 
            expression=mode, 
            average=True, 
            path_method="double-greedy-degree-then-fill", 
            _einsum=True, 
            _dediag=True
        )
        times['einsum_dediag'] = time.time() - start_time
        results['einsum_dediag'] = result_3
        
        # Test Method 4: _einsum=True, _dediag=False
        start_time = time.time()
        result_4 = ustat(
            tensors=tensors, 
            expression=mode, 
            average=True, 
            path_method="double-greedy-degree-then-fill", 
            _einsum=True, 
            _dediag=False
        )
        times['einsum_baseline'] = time.time() - start_time
        results['einsum_baseline'] = result_4
        
        # Print results for this size
        baseline_result = results['baseline']
        
        for method_name in ['baseline', 'path_dediag', 'einsum_dediag', 'einsum_baseline']:
            result_val = results[method_name]
            time_val = times[method_name]
            
            # Check if results match (within tolerance)
            if isinstance(result_val, (torch.Tensor, np.ndarray)):
                if hasattr(result_val, 'item'):
                    result_val = result_val.item()
                else:
                    result_val = float(result_val)
            
            if isinstance(baseline_result, (torch.Tensor, np.ndarray)):
                if hasattr(baseline_result, 'item'):
                    baseline_val = baseline_result.item()
                else:
                    baseline_val = float(baseline_result)
            else:
                baseline_val = baseline_result
            
            # Check if results match within relative tolerance
            match = "✓" if abs(result_val - baseline_val) < 1e-6 * abs(baseline_val) else "✗"
            
            method_display = {
                'baseline': 'Path + No Dediag',
                'path_dediag': 'Path + Dediag', 
                'einsum_dediag': 'Einsum + Dediag',
                'einsum_baseline': 'Einsum + No Dediag'
            }[method_name]
            
            print(f"{size:<8} {method_display:<25} {time_val:<12.4f} {result_val:<15.6e} {match:<8}")
    
    print("\n" + "=" * 80)
    print("Test completed!")
    print("✓ = Results match baseline")
    print("✗ = Results differ from baseline")

if __name__ == "__main__":
    test_tensor_performance()